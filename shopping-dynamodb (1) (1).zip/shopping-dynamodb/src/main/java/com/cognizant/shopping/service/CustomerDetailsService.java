package com.cognizant.shopping.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.shopping.document.Admin;
import com.cognizant.shopping.document.Customer;
import com.cognizant.shopping.repository.AdminRepository;
import com.cognizant.shopping.repository.CustomerRepository;

@Service
public class CustomerDetailsService implements UserDetailsService{

	@Autowired
	private CustomerRepository customerRespository;
	
	@Autowired
	private AdminRepository adminRepository;
	
	@Override
	public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
		
		Customer customer = customerRespository.findByLoginId(loginId);
		Admin admin;
		if((admin = adminRepository.findByLoginId(loginId))!=null)
		{
			UserDetails user  = User.builder().username(admin.getLoginId())
					                          .password(admin.getPassword())
					                          .authorities(new SimpleGrantedAuthority("ADMIN"))
					                          .build();
			return user;
		}
		return new User(customer.getLoginId(),customer.getPassword(),new ArrayList<GrantedAuthority>());
	}

}
