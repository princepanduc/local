package com.cognizant.shopping.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.shopping.document.Customer;
import com.cognizant.shopping.document.Order;
import com.cognizant.shopping.document.Product;
import com.cognizant.shopping.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired 
	private CustomerService customerService;
	
	@Autowired
	private ProductService productService;
	
	
	public List<Order> getAllOrders()
	{
		return (List<Order>) this.orderRepository.findAll();
	}
	
	public void createOrder(String loginId)
	{
		Customer customer = this.customerService.getCustomer(loginId);
		List<String> cart = customer.getCart();
		customer.setCart(new ArrayList<>());
		customerService.save(customer);
		List<Order> orders = new ArrayList<>();
		for(String productId : cart)
		{
			Order order = new Order();
			order.setProductId(productId);
			order.setCustomerId(customer.getCustomerId());
			order.setOrderedDate(LocalDate.now().toString());
			order.setDeliveryDate(LocalDate.now().plusDays(5).toString());
			orders.add(order);
			Product product = this.productService.getProduct(productId).get();
			product.setQuantity(product.getQuantity()-1);
			productService.addProduct(product);
		}
		orderRepository.saveAll(orders);
	}
	
	public List<Order> getCustomerOrders(String loginId)
	{
		Customer customer = customerService.getCustomer(loginId);
		return this.orderRepository.findByCustomerId(customer.getCustomerId());
	}
	
	public List<Order> getProductOrders(String productId)
	{
		return this.orderRepository.findByProductId(productId);
	}
	
	public void deleteOrder(String orderId)
	{
		Order order = this.orderRepository.findById(orderId).get();
		Product product = productService.getProduct(order.getProductId()).get();
		product.setQuantity(product.getQuantity()+1);
		productService.addProduct(product);
		this.orderRepository.deleteById(orderId);
		
		
	}	
}
