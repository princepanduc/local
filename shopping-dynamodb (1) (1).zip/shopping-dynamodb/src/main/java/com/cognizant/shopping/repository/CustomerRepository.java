package com.cognizant.shopping.repository;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.shopping.document.Customer;

@Repository
@EnableScan
public interface CustomerRepository extends CrudRepository<Customer,String>{
	 
	public Customer findByLoginId(String loginId);
	
	public Customer findByEmail(String loginId,String email);
}
