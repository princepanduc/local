package com.cognizant.shopping.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.shopping.document.Product;

@Repository
@EnableScan
public interface ProductRepository extends CrudRepository<Product,String>{

	public Product findByProductId(String productId);
	
	public List<Product> findByProductNameContaining(String productName);
	
	
	
}
