package com.cognizant.shopping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.shopping.document.Product;
import com.cognizant.shopping.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	public List<Product> getAllProducts()
	{
		return (List<Product>) this.productRepository.findAll();
	}
	
	public Optional<Product> getProduct(String productId)
	{
		return this.productRepository.findById(productId);
	}
	public String addProduct(Product product)
	{
		product.setProductName(product.getProductName().toLowerCase());
		Product createdProduct = this.productRepository.save(product);
		return createdProduct.getProductId();
		
	}
	public List<Product> searchProducts(String productName)
	{
		productName = productName.toLowerCase();
		return this.productRepository.findByProductNameContaining(productName);	
	}
	public void deleteProduct(String productId)
	{
		this.productRepository.deleteById(productId);
	}
	public void updateProductStatus(String productId,String status)
	{
		Product product = this.productRepository.findByProductId(productId);
		product.setProductStatus(status);
		this.productRepository.save(product);
	}
	
	
}
