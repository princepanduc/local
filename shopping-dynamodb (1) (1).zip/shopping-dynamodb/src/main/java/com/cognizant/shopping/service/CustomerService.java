package com.cognizant.shopping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.shopping.document.Customer;
import com.cognizant.shopping.document.Product;
import com.cognizant.shopping.exception.IncorrectPasswordException;
import com.cognizant.shopping.exception.UserAlreadyExistsException;
import com.cognizant.shopping.exception.UsernameNotFoundException;
import com.cognizant.shopping.model.LoginCredentials;
import com.cognizant.shopping.model.User;
import com.cognizant.shopping.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	

	
	@Autowired
	private ProductService productService;
	
	public void addCustomer(User user)
	{
		Customer customer = new Customer();
		BeanUtils.copyProperties(user, customer);
		
		Customer c1 = this.customerRepository.findByLoginId(customer.getLoginId());
		Customer c2 = this.customerRepository.findByLoginId(customer.getLoginId());
		
		if(c1!=null || c2!=null)
			throw new UserAlreadyExistsException("Either login id or email are already exists!");
		
		this.customerRepository.save(customer);
	}
	
	public boolean validateCredentials(LoginCredentials loginCredentials)
	{
		Customer customer = this.customerRepository.findByLoginId(loginCredentials.getLoginId());
		if(customer == null)
			throw new UsernameNotFoundException("Login Id does not exists!!");
		
		if(!customer.getPassword().equals(loginCredentials.getPassword()))
			throw new IncorrectPasswordException("Password is not correct");
		return true;
	}
	
	public void resetPassword(String loginId,String password)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		if(customer == null)
			throw new UsernameNotFoundException("Login Id does not exists!!");
		
		customer.setPassword(password);
		this.customerRepository.save(customer);
		
	}
	
	public List<Customer> getAllCustomers()
	{
		return (List<Customer>) this.customerRepository.findAll();
	}
	
	public void addToCart(String loginId,String productId)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		if(customer.getCart() == null)
		{
			customer.setCart(new ArrayList<>());
		}
		customer.getCart().add(productId);
		this.customerRepository.save(customer);
	}
	
	public void deleteCartItem(String loginId,String productId)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		if(customer.getCart() == null)
		{
			customer.setCart(new ArrayList<>());
		}
		customer.getCart().remove(productId);
		this.customerRepository.save(customer);
	}
	
	public List<Product> getCartItems(String loginId)
	{
		Customer customer = this.customerRepository.findByLoginId(loginId);
		List<String> productIds = customer.getCart();
		
		List<Product> products = new ArrayList<>();
		for(String productId : productIds)
		{
			Optional<Product> product = productService.getProduct(productId);
			if(product.isPresent())
				products.add(product.get());
		}
		return products;
	}
	
	public Customer getCustomer(String loginId)
	{
		return this.customerRepository.findByLoginId(loginId);
	}
	
	public Customer save(Customer customer)
	{
		return this.customerRepository.save(customer);
	}
	
	
}
