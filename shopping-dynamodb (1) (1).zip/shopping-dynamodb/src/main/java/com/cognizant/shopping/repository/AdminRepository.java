package com.cognizant.shopping.repository;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.shopping.document.Admin;

@Repository
@EnableScan
public interface AdminRepository extends CrudRepository<Admin,String>{
	
	public Admin findByLoginId(String loginId);

}
