package com.cognizant.shopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.shopping.document.Admin;
import com.cognizant.shopping.exception.IncorrectPasswordException;
import com.cognizant.shopping.exception.UsernameNotFoundException;
import com.cognizant.shopping.model.ApiResponse;
import com.cognizant.shopping.model.LoginCredentials;
import com.cognizant.shopping.repository.AdminRepository;
import com.cognizant.shopping.service.AuthenticationService;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/api/v1.0/shopping")
public class AdminController {

	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired 
	private AuthenticationService authService;

	@PostMapping("/admins/create")
	public ResponseEntity<ApiResponse> createAdmin(@RequestBody Admin admin)
	{
		this.adminRepository.save(admin);
		ApiResponse response = new  ApiResponse("Admin created successfully");
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}
	
	@PostMapping("/admins/login")
	public ResponseEntity<ApiResponse> login(@RequestBody LoginCredentials loginCredentials)
	{
		Admin admin = this.adminRepository.findByLoginId(loginCredentials.getLoginId());
		if(admin==null)
			throw new UsernameNotFoundException("Admin not found with the given loginid");
		if(!admin.getPassword().equals(loginCredentials.getPassword()))
			throw new IncorrectPasswordException("Incorrect password");
		String token = authService.generateToken(loginCredentials, true);
		ApiResponse response = new ApiResponse(token);
		return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
	}
	
	
	
}
