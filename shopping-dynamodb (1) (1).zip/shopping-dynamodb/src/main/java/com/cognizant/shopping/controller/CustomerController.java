package com.cognizant.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.shopping.document.Customer;
import com.cognizant.shopping.document.Product;
import com.cognizant.shopping.model.ApiErrorResponse;
import com.cognizant.shopping.model.ApiResponse;
import com.cognizant.shopping.model.LoginCredentials;
import com.cognizant.shopping.model.User;
import com.cognizant.shopping.service.AuthenticationService;
import com.cognizant.shopping.service.CustomerService;
import com.cognizant.shopping.service.ProductService;

@RestController
@RequestMapping("/api/v1.0/shopping/customers")
@CrossOrigin(origins="*")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	AuthenticationService authenticationService;
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/register")
	public ResponseEntity<ApiResponse> addCustomer(@RequestBody User user)
	{
	    this.customerService.addCustomer(user);
		ApiResponse response = new ApiResponse("User haas been created");
		return new ResponseEntity<ApiResponse>(response,HttpStatus.CREATED);
	}
	
	@PostMapping("/login")
	public ResponseEntity<ApiResponse> login(@RequestBody LoginCredentials loginCredentials)
	{
		this.customerService.validateCredentials(loginCredentials);
		String token = this.authenticationService.generateToken(loginCredentials,false);
		ApiResponse response = new ApiResponse(token);
		return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/{loginId}")
	public ResponseEntity<Customer> getCustomer(@PathVariable("loginId") String loginId)
	{
		Customer customers = this.customerService.getCustomer(loginId);
		return new ResponseEntity<Customer>(customers,HttpStatus.OK);
	}
	
	@PostMapping(path="/{loginId}/forgot",consumes=MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<ApiResponse> resetPassword(@PathVariable("loginId") String loginId,@RequestBody String password)
	{
		this.customerService.resetPassword(loginId, password);
		ApiResponse response = new ApiResponse("Password updated successfully!");
		return new ResponseEntity<ApiResponse>(response,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("")
	public ResponseEntity<List<Customer>> getAllCustomers()
	{
		List<Customer> customers = this.customerService.getAllCustomers();
		return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK);
	}
	
	@PostMapping("/{loginId}/cart/{productId}")
	public ResponseEntity<ApiResponse> addToCart(@PathVariable("loginId") String loginId,@PathVariable("productId") String productId)
	{
		this.customerService.addToCart(loginId, productId);
		return new ResponseEntity<>(new ApiResponse("Added to cart"),HttpStatus.OK);
	}
	
	@DeleteMapping("/{loginId}/delete/cart/{productId}")
	public ResponseEntity<ApiResponse> deleteCartItem(@PathVariable("loginId") String loginId,@PathVariable("productId") String productId)
	{
		this.customerService.deleteCartItem(loginId, productId);
		return new ResponseEntity<>(new ApiResponse("deleted from cart"),HttpStatus.OK);
	}
	
	@GetMapping("/{loginId}/cart")
	public ResponseEntity<List<Product>> getCartItems(@PathVariable("loginId") String loginId)
	{
		List<Product> products = this.customerService.getCartItems(loginId);
		return new ResponseEntity<>(products,HttpStatus.OK);
	}
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleUserAlreadyExistsException(Exception e)
	{
		ApiErrorResponse errorResponse = new ApiErrorResponse(e.getMessage());
		return new ResponseEntity<ApiErrorResponse>(errorResponse,HttpStatus.BAD_REQUEST);	
	}
	
	

}
