package com.cognizant.shopping.exception;

public class IncorrectPasswordException extends RuntimeException{
	
	public IncorrectPasswordException(String message) {
		super(message);
	}

}
