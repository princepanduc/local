export class AddProduct {
    productId!:string;
    title!:string;
    price!:string;
    description!:string;
    category!:string;
    rating!:string;
}
