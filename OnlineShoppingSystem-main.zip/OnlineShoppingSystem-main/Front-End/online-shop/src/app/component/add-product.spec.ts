import { AddProduct } from './add-product';

describe('AddProduct', () => {
  it('should create an instance', () => {
    expect(new AddProduct()).toBeTruthy();
  });
});
