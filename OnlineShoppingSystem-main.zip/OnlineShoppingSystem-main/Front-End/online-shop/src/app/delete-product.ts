export class DeleteProduct {
    productId!:string;
}
