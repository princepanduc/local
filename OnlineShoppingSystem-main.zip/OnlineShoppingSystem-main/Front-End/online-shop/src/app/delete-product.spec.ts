import { DeleteProduct } from './delete-product';

describe('DeleteProduct', () => {
  it('should create an instance', () => {
    expect(new DeleteProduct()).toBeTruthy();
  });
});
